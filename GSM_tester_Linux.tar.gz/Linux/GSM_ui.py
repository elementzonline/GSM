from PyQt4 import QtCore, QtGui
from PyQt4.QtCore import SIGNAL, QObject
import sys
import serial
import glob
import threading

            
gsm_ser = serial.Serial()
gsm_ser.port=""
gsm_ser.baudrate=9600
gsm_ser.timeout=2
gsm_ser.xonxoff = False
gsm_ser.rtscts = False
gsm_ser.bytesize = serial.EIGHTBITS
gsm_ser.parity = serial.PARITY_NONE
gsm_ser.stopbits = serial.STOPBITS_ONE


connected = False
        
#def read_from_port(ser):
    #global connected
    #while True & connected:
        ##print("test")
        #reading = str(ser.readline().decode()).rstrip()
        #if len(reading) > 0:
            #print str(reading)

def serial_ports():
    ports = glob.glob('/dev/tty[A-Za-z]*')
    
    result = []
    for port in ports:
        try:
            s = serial.Serial(port)
            s.close()
            result.append(port)
        except (OSError, serial.SerialException):
            pass
    return result

serialPorts = serial_ports()
numSerial = len(serial_ports())



def sendCommand(at_com):
    gsm_ser.flushInput()
    gsm_ser.flushOutput()    
    gsm_ser.write(at_com + '\r')
    
def getResponse():
    gsm_ser.flushInput()
    gsm_ser.flushOutput()     
    response = gsm_ser.readline() # comment this line if echo off
    response = gsm_ser.readline()
    response = response.rstrip()
    return response

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_Form(QtGui.QWidget):
    def __init__(self):
        QtGui.QWidget.__init__(self)
        self.setupUi(self)    
    
   
    def setupUi(self, Form):
        Form.setObjectName(_fromUtf8("Form"))
        Form.resize(412, 324)
        self.serialSelectCombo = QtGui.QComboBox(Form)
        self.serialSelectCombo.setGeometry(QtCore.QRect(100, 250, 116, 24))
        self.serialSelectCombo.setAutoFillBackground(False)
        self.serialSelectCombo.setObjectName(_fromUtf8("serialSelectCombo"))
        if (numSerial == 0):
            self.serialSelectCombo.addItem(_fromUtf8("--No Port--"))
        else:
            for i in range(numSerial):
                self.serialSelectCombo.addItem(_fromUtf8(serialPorts[i]))
        self.SerialLog = QtGui.QPlainTextEdit(Form)
        self.SerialLog.setGeometry(QtCore.QRect(4, 61, 376, 180))
        self.SerialLog.setVerticalScrollBarPolicy(QtCore.Qt.ScrollBarAsNeeded)
        self.SerialLog.setReadOnly(True)
        self.SerialLog.setObjectName(_fromUtf8("SerialLog"))
        self.callNumberInput = QtGui.QLineEdit(Form)
        self.callNumberInput.setGeometry(QtCore.QRect(240, 0, 131, 23))
        self.callNumberInput.setObjectName(_fromUtf8("callNumberInput"))
        self.callButton = QtGui.QPushButton(Form)
        self.callButton.setGeometry(QtCore.QRect(240, 30, 133, 24))
        self.callButton.setObjectName(_fromUtf8("callButton"))
        self.closePortButton = QtGui.QPushButton(Form)
        self.closePortButton.setGeometry(QtCore.QRect(300, 300, 89, 24))
        self.closePortButton.setObjectName(_fromUtf8("closePortButton"))
        self.openPortButton = QtGui.QPushButton(Form)
        self.openPortButton.setGeometry(QtCore.QRect(100, 300, 89, 24))
        self.openPortButton.setObjectName(_fromUtf8("openPortButton"))
        self.sendATButton = QtGui.QPushButton(Form)
        self.sendATButton.setGeometry(QtCore.QRect(0, 30, 133, 24))
        self.sendATButton.setObjectName(_fromUtf8("sendATButton"))
        self.atCommandInput = QtGui.QLineEdit(Form)
        self.atCommandInput.setGeometry(QtCore.QRect(0, 0, 181, 23))
        self.atCommandInput.setObjectName(_fromUtf8("atCommandInput"))
        self.baudBox = QtGui.QComboBox(Form)
        self.baudBox.setGeometry(QtCore.QRect(300, 250, 101, 24))
        self.baudBox.setObjectName(_fromUtf8("baudBox"))
        self.baudBox.addItem(_fromUtf8(""))
        self.baudBox.addItem(_fromUtf8(""))
        self.baudBox.addItem(_fromUtf8(""))
        self.baudBox.addItem(_fromUtf8(""))
        self.baudBox.addItem(_fromUtf8(""))
        self.baudBox.addItem(_fromUtf8(""))        

        self.retranslateUi(Form)
        QtCore.QMetaObject.connectSlotsByName(Form)

    def retranslateUi(self, Form):
        Form.setWindowTitle(_translate("Form", "Form", None))
        self.baudBox.setItemText(0, _translate("Form", "4800", None))
        self.baudBox.setItemText(1, _translate("Form", "9600", None))
        self.baudBox.setItemText(2, _translate("Form", "19200", None))
        self.baudBox.setItemText(3, _translate("Form", "38400", None))
        self.baudBox.setItemText(4, _translate("Form", "57600", None))
        self.baudBox.setItemText(5, _translate("Form", "115200", None))        
        self.callButton.setText(_translate("Form", "Call", None))
        self.closePortButton.setText(_translate("Form", "Close Port", None))
        self.openPortButton.setText(_translate("Form", "Open Port", None))
        self.sendATButton.setText(_translate("Form", "SendATCommand", None))
        
        self.openPortButton.clicked.connect(self.openPort)
        self.closePortButton.clicked.connect(self.closePort)
        self.sendATButton.clicked.connect(self.sendAT)
        self.callButton.clicked.connect(self.callPress)
        self.serialSelectCombo.highlighted.connect(self.refreshPort)
        #self.serialSelectCombo.mousePressEvent(QtGui.QMouseEvent)
        self.disableButtons()        
    
    def read_from_port(self,ser):
        global connected
        while True & connected:
            #print("test")
            reading = ser.readline()
            if len(reading) > 0:
                reading = str(reading).rstrip()
                if len(reading) > 0:
                    try:
                        reading.decode('ascii')
                        self.SerialLog.insertPlainText(QtCore.QString(reading+'\n'))
                    except:
                        self.SerialLog.insertPlainText(QtCore.QString('Non ascii characters'+'\n'))
                    #print str(reading) 
                
     
    def refreshPort(self): 
        serialPorts = serial_ports()
        numSerial = len(serial_ports()) 
        for i in range(self.serialSelectCombo.count()):
            self.serialSelectCombo.removeItem(i)
        if (numSerial == 0):
                    self.serialSelectCombo.addItem(_fromUtf8("--No Port--"))
        else:
            for i in range(numSerial):
                self.serialSelectCombo.addItem(_fromUtf8(serialPorts[i]))        
     
    def disableButtons(self):  
        self.callButton.setEnabled(False)
        self.sendATButton.setEnabled(False)
        self.closePortButton.setEnabled(False)
        self.openPortButton.setEnabled(True)
        self.baudBox.setEnabled(True)
    
    def enableButtons(self):  
        self.callButton.setEnabled(True)
        self.sendATButton.setEnabled(True)
        self.closePortButton.setEnabled(True) 
        self.openPortButton.setEnabled(False)
        self.baudBox.setEnabled(False)

    def openPort(self):
        try: 
            gsm_ser.port = str(self.serialSelectCombo.currentText())
            gsm_ser.baudrate = str(self.baudBox.currentText())
            gsm_ser.open()
            gsm_ser.flushInput()
            gsm_ser.flushOutput() 
            self.SerialLog.insertPlainText(QtCore.QString('Serial port Opened\n'))
            self.enableButtons()
            
            global connected
            connected = True             
            thread = threading.Thread(target=self.read_from_port, args=(gsm_ser,))
            thread.start() 
                       
        except:
            self.SerialLog.insertPlainText(QtCore.QString('Cannot open serial port\n'))
            
    def closePort(self):
        try: 
            global connected
            connected = False            
            gsm_ser.close()
            self.SerialLog.insertPlainText(QtCore.QString('Serial port closed\n'))
            self.disableButtons()          
        except:
            self.SerialLog.insertPlainText(QtCore.QString('Cannot close serial port\n')) 
            
    def sendAT(self):
        text = self.atCommandInput.text()
        sendCommand(str(text))
        
    def callPress(self):
        text = self.callNumberInput.text()
        sendCommand('ATD'+str(text)+';') 

if __name__ == '__main__':
    app = QtGui.QApplication(sys.argv)
    ex= Ui_Form()
    ex.show()
    sys.exit(app.exec_())